package com.apimonitor.controller;

import com.apimonitor.entity.MonitoringLog;
import com.apimonitor.repository.MonitoringLogRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/logs")
@CrossOrigin("*")
public class MonitoringController {

    private final MonitoringLogRepository repository;

    public MonitoringController(
            MonitoringLogRepository repository) {

        this.repository = repository;

    }

    @GetMapping("/{apiId}")
    public List<MonitoringLog> history(
            @PathVariable Long apiId) {

        System.out.println("History API called");

        List<MonitoringLog> logs =
                repository.findTop100ByApiEndpointIdOrderByCheckedAtDesc(apiId);

        System.out.println("Fetched " + logs.size() + " logs");

        return logs;
    }

}